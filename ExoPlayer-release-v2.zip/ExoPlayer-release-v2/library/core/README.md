# ExoPlayer core library module #

The core of the ExoPlayer library.

## Links ##

* [Javadoc][]: Note that this Javadoc is combined with that of other modules.

[Javadoc]: https://exoplayer.dev/doc/reference/index.html
