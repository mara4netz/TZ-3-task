# ExoPlayer main demo #

This is the main ExoPlayer demo application. It uses ExoPlayer to play a number
of test streams. It can be used as a starting point or reference project when
developing other applications that make use of the ExoPlayer library.

Please see the [demos README](../README.md) for instructions on how to build and
run this demo.
